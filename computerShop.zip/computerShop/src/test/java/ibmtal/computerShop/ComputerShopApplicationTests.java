package ibmtal.computerShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComputerShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
